/* ########## Hreiðar Pétursson ########## */
/*  ######## Javascript Áfanginn ########  */
/*   ######### Skilaverkefni 2 #########   */
/*    ########   Janúar 2024   ########    */


// Got this object of colors online so I decided to just use it
/* export const colors = {
    red: "rgba(255, 0, 0, 1)",
    green: "rgba(0, 255, 0, 1)",
    blue: "rgba(0, 0, 255, 1)",
    yellow: "rgba(255, 255, 0, 1)",
    orange: "rgba(255, 165, 0, 1)",
    purple: "rgba(128, 0, 128, 1)",
    pink: "rgba(255, 192, 203, 1)",
    cyan: "rgba(0, 255, 255, 1)",
    magenta: "rgba(255, 0, 255, 1)",
    lime: "rgba(0, 255, 0, 1)",
    teal: "rgba(0, 128, 128, 1)",
    olive: "rgba(128, 128, 0, 1)",
    maroon: "rgba(128, 0, 0, 1)",
    navy: "rgba(0, 0, 128, 1)",
    aqua: "rgba(0, 255, 255, 1)",
    fuchsia: "rgba(255, 0, 255, 1)",
    gray: "rgba(128, 128, 128, 1)",
    silver: "rgba(192, 192, 192, 1)",
    black: "rgba(0, 0, 0, 1)",
    white: "rgba(255, 255, 255, 1)",
    darkBlue: "rgba(0, 0, 70, 1)",
    lightBlue: "rgba(0, 0, 200, 1)",
  };

 */


// ----- Global Variables and Constants ----- //


// Set the Constants for the width and height
/* export const canvasWidth = 600;
export const canvasHeight = 600;
export const canvasSize = 600;
export const canvasWidthStart = 0;
export const canvasHeightStart = 0; */
/* 
export let gamePaused = false; // Pause the game by freezing it

// This function is called every time live changes or score is added. It updates the html
export function updateGameStats() {
    document.getElementById('lives').textContent = 'Lives: ' + lives;
    document.getElementById('score').textContent = 'Score: ' + score;
}
 */
