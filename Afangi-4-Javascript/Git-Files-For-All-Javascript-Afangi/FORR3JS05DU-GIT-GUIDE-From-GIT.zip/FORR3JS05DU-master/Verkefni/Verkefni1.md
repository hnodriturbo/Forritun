## Verkefni 1

- 15% af heildareinkunn.

---

### Verkefnalýsing
Stofnaðu reikning (notaðu nafn + ártal sem notendanafn) í [freeCodeCamp](https://www.freecodecamp.org/) til að halda utan um framvinduna þína. <br>
Gerðu eftirfarandi **121** gagnvirkar æfingar: 
1. [Basic JavaScript](https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/basic-javascript/) (allar 113 æfingarnar) 
1. Fyrstu 8 æfingarnar í [ES6](https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/es6/). Sleppa frá og með _`Use Destructuring Assignment to Extract Values from Objects`_.

<!-- Hér eru [skýringarmyndbönd](https://scrimba.com/course/ges6). --> 

---

### Námsmat og skil

- Gefin er einkunn í hlutfalli fyrir þær æfingar sem eru kláraðar.
- Skilaðu [skjámynd](https://github.com/GunnarThorunnarson/FORR3JS05DU/blob/master/Myndir/v1_freecodecamp.PNG) af árangri. 
- Sein skil eru ekki í boði.
